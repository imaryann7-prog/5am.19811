/* =====================================================================

   ✏️  EDIT HERE — everything you need to change lives in this one
       object. You should never need to touch anything below the
       line that says "DO NOT EDIT BELOW THIS LINE".

       After changing anything here, just refresh the page to see it.

===================================================================== */

const CONFIG = {

  // The password she needs to type to unlock the surprise.
  // Not case sensitive, extra spaces are ignored.
  password: "YOUR_PASSWORD",

  // Her name — shown big on the reveal scene and the final scene.
  name: "HER NAME",

  // Path to your music file. Put the file inside the /music folder
  // and put its filename here. Leave as "" to disable music.
  music: "music/birthday.mp3",

  // Fonts — change the names here if you want a different look.
  // "display" is used for big emotional titles, "script" is used
  // for the letter and "like" cards, "body" is used everywhere else.
  fonts: {
    display: "'Playfair Display', serif",
    script: "'Cormorant Garamond', serif",
    body: "'Poppins', sans-serif"
  },

  // Main colors. Use any hex code.
  colors: {
    background: "#0a0a0f",
    accent: "#e8b4bc",        // rose gold — buttons, highlights
    accentStrong: "#c9184a",  // deeper crimson — used for glow/gradient
    gold: "#d4af37"           // gold — small decorative details
  },

  // The message that appears big on the "reveal" scene, above her name.
  revealHeadline: "HAPPY BIRTHDAY",

  // Memories — add or remove as many as you like. For each one:
  //   src: path to the photo inside the /images folder
  //        (leave src as "" to show a placeholder heart instead of a photo)
  //   caption: the text under the photo (leave "" for no caption)
  memories: [
    { src: "", caption: "This moment..." },
    { src: "", caption: "One of my favourite memories..." },
    { src: "", caption: "I still smile thinking about this." },
    { src: "", caption: "You, being you." },
    { src: "", caption: "A day I never want to forget." },
    { src: "", caption: "This one is my favourite." }
  ],

  // Things you like about her. Add or remove as many lines as you want.
  likes: [
    "Your smile ❤️",
    "Your energy ✨",
    "Your kindness 🌸",
    "Your sense of humour 😂",
    "The way you make ordinary moments special.",
    "How you make everyone around you feel seen."
  ],

  // Your personal letter. Each item in this list becomes its own
  // paragraph, and they reveal one after another. Write as many
  // paragraphs as you like.
  letter: [
    "I wanted today to feel different — not just another birthday, but a moment where you actually stop and feel how loved you are.",
    "Every year with you adds something I didn't know I was missing. I don't say it enough, so I wanted to build something that says it properly.",
    "Thank you for being exactly who you are. I hope this year brings you everything you deserve, and more.",
    "Happy birthday. I mean every word of this."
  ],

  // Final scene text, shown after she taps "Open it".
  finalMessageTop: "I hope this little surprise made you smile.",

  // Button labels — change the wording if you like.
  buttons: {
    unlock: "Unlock",
    cutCake: "Cut the Cake",
    continue: "Continue",
    openFinal: "Open it"
  }

};

/* =====================================================================
   DO NOT EDIT BELOW THIS LINE
   (unless you're comfortable with JavaScript — everything below just
   reads the CONFIG above and runs the website)
===================================================================== */

// ---- Apply CONFIG to CSS variables ----------------------------------
(function applyTheme() {
  const root = document.documentElement.style;
  root.setProperty('--bg', CONFIG.colors.background);
  root.setProperty('--accent', CONFIG.colors.accent);
  root.setProperty('--accent-strong', CONFIG.colors.accentStrong);
  root.setProperty('--gold', CONFIG.colors.gold);
  root.setProperty('--font-display', CONFIG.fonts.display);
  root.setProperty('--font-script', CONFIG.fonts.script);
  root.setProperty('--font-body', CONFIG.fonts.body);
})();

// ---- Apply CONFIG text to the DOM ------------------------------------
function applyText() {
  document.getElementById('reveal-happy').textContent = CONFIG.revealHeadline;
  document.getElementById('reveal-name').textContent = CONFIG.name + ' ❤';
  document.getElementById('final-happy').textContent = 'Happy Birthday,';
  document.getElementById('final-name').textContent = CONFIG.name + ' ❤';
  document.getElementById('final-message').textContent = CONFIG.finalMessageTop;

  document.querySelector('#password-form .primary-btn').innerHTML =
    CONFIG.buttons.unlock + ' <span class="spark">✨</span>';
  document.getElementById('cut-cake-btn').innerHTML =
    CONFIG.buttons.cutCake + ' <span class="spark">🎂</span>';
  document.getElementById('open-final-btn').innerHTML =
    CONFIG.buttons.openFinal + ' <span class="spark">❤️</span>';
  document.querySelectorAll('[id^="continue-to-"]').forEach(btn => {
    btn.innerHTML = CONFIG.buttons.continue + ' <span class="spark">✨</span>';
  });
}
applyText();

// ---- Scene navigation --------------------------------------------------
const scenes = ['scene-password', 'scene-cake', 'scene-reveal', 'scene-memories', 'scene-likes', 'scene-letter', 'scene-final'];

function goToScene(id) {
  const current = document.querySelector('.scene.active');
  const next = document.getElementById(id);
  if (!next || current === next) return;

  if (current) {
    current.classList.add('leaving');
    current.classList.remove('active');
    setTimeout(() => current.classList.remove('leaving'), 900);
  }

  next.classList.add('active');

  // Trigger scene-specific entrance behaviour
  if (id === 'scene-memories') revealMemoryCards();
  if (id === 'scene-likes') revealLikeCards();
  if (id === 'scene-letter') revealLetterParagraphs();
}

// ---- SCENE 1: password --------------------------------------------------
const passwordForm = document.getElementById('password-form');
const passwordInput = document.getElementById('password-input');
const passwordError = document.getElementById('password-error');

passwordForm.addEventListener('submit', function (e) {
  e.preventDefault();
  const typed = passwordInput.value.trim().toLowerCase();
  const correct = CONFIG.password.trim().toLowerCase();

  if (typed.length > 0 && typed === correct) {
    passwordError.classList.remove('show');
    startMusic();
    document.getElementById('music-control').classList.remove('hidden');
    goToScene('scene-cake');
  } else {
    passwordError.classList.add('show');
    passwordInput.classList.remove('shake');
    // restart animation
    void passwordInput.offsetWidth;
    passwordInput.classList.add('shake');
  }
});

// ---- SCENE 2: cake --------------------------------------------------
const cutCakeBtn = document.getElementById('cut-cake-btn');
const cakeEl = document.getElementById('cake');

cutCakeBtn.addEventListener('click', function () {
  cutCakeBtn.disabled = true;
  document.querySelectorAll('.candle').forEach(c => c.classList.add('out'));
  cakeEl.classList.add('cutting');
  burstConfetti();
  startMusic();

  setTimeout(() => {
    goToScene('scene-reveal');
    burstConfetti();
  }, 1200);
});

// ---- SCENE 3: reveal → memories --------------------------------------------------
document.getElementById('continue-to-memories-btn').addEventListener('click', () => goToScene('scene-memories'));

// ---- SCENE 4: memories --------------------------------------------------
const memoryGrid = document.getElementById('memory-grid');

function buildMemoryCards() {
  memoryGrid.innerHTML = '';
  CONFIG.memories.forEach((mem, i) => {
    const card = document.createElement('div');
    card.className = 'memory-card';

    if (mem.src) {
      const img = document.createElement('img');
      img.className = 'memory-photo';
      img.src = mem.src;
      img.alt = mem.caption || 'memory photo';
      img.loading = 'lazy';
      card.appendChild(img);
    } else {
      const placeholder = document.createElement('div');
      placeholder.className = 'memory-photo placeholder';
      placeholder.textContent = '🤍';
      card.appendChild(placeholder);
    }

    if (mem.caption) {
      const cap = document.createElement('div');
      cap.className = 'memory-caption';
      cap.textContent = mem.caption;
      card.appendChild(cap);
    }

    card.addEventListener('click', () => {
      card.style.transform = 'scale(0.95)';
      setTimeout(() => { card.style.transform = ''; }, 150);
    });

    memoryGrid.appendChild(card);
  });
}
buildMemoryCards();

function revealMemoryCards() {
  const cards = memoryGrid.querySelectorAll('.memory-card');
  cards.forEach((card, i) => {
    setTimeout(() => card.classList.add('in-view'), i * 130);
  });
}

document.getElementById('continue-to-likes-btn').addEventListener('click', () => goToScene('scene-likes'));

// ---- SCENE 5: likes --------------------------------------------------
const likesGrid = document.getElementById('likes-grid');

function buildLikeCards() {
  likesGrid.innerHTML = '';
  CONFIG.likes.forEach(text => {
    const card = document.createElement('div');
    card.className = 'like-card';
    card.textContent = text;
    likesGrid.appendChild(card);
  });
}
buildLikeCards();

function revealLikeCards() {
  const cards = likesGrid.querySelectorAll('.like-card');
  cards.forEach((card, i) => {
    setTimeout(() => card.classList.add('in-view'), i * 220);
  });
}

document.getElementById('continue-to-letter-btn').addEventListener('click', () => goToScene('scene-letter'));

// ---- SCENE 6: letter --------------------------------------------------
const letterPaper = document.getElementById('letter-paper');

function buildLetter() {
  letterPaper.innerHTML = '';
  CONFIG.letter.forEach(paragraph => {
    const p = document.createElement('p');
    p.textContent = paragraph;
    letterPaper.appendChild(p);
  });
}
buildLetter();

function revealLetterParagraphs() {
  const paragraphs = letterPaper.querySelectorAll('p');
  paragraphs.forEach((p, i) => {
    setTimeout(() => p.classList.add('in-view'), i * 700 + 200);
  });
}

document.getElementById('continue-to-final-btn').addEventListener('click', () => goToScene('scene-final'));

// ---- SCENE 7: final --------------------------------------------------
document.getElementById('open-final-btn').addEventListener('click', function () {
  document.getElementById('final-before').classList.add('hidden');
  document.getElementById('final-after').classList.remove('hidden');
  burstConfetti();
  setTimeout(burstConfetti, 500);
});

// ---- MUSIC --------------------------------------------------
const musicEl = document.getElementById('bg-music');
const musicControl = document.getElementById('music-control');
const musicToggleBtn = document.getElementById('music-toggle-btn');
const musicIcon = document.getElementById('music-icon');
let musicStarted = false;

if (CONFIG.music) {
  musicEl.src = CONFIG.music;
  musicEl.volume = 0.6;
}

function startMusic() {
  if (!CONFIG.music || musicStarted) return;
  musicStarted = true;
  const playPromise = musicEl.play();
  if (playPromise && playPromise.catch) {
    playPromise.then(() => setPlayingIcon(true)).catch(() => {
      // Autoplay was blocked — the visible play/pause button still works.
      setPlayingIcon(false);
    });
  }
}

function setPlayingIcon(isPlaying) {
  musicIcon.textContent = isPlaying ? '♪' : '♫';
  musicToggleBtn.classList.toggle('playing', isPlaying);
}

musicToggleBtn.addEventListener('click', function () {
  if (!CONFIG.music) return;
  if (musicEl.paused) {
    musicEl.play().then(() => setPlayingIcon(true)).catch(() => {});
  } else {
    musicEl.pause();
    setPlayingIcon(false);
  }
});

// ---- AMBIENT FLOATING HEARTS / PARTICLES --------------------------------------------------
const ambientLayer = document.getElementById('ambient-layer');
const floatSymbols = ['❤', '♥', '✦', '·'];

function spawnFloaty() {
  const el = document.createElement('div');
  el.className = 'floaty';
  el.textContent = floatSymbols[Math.floor(Math.random() * floatSymbols.length)];
  const size = 10 + Math.random() * 16;
  el.style.left = Math.random() * 100 + 'vw';
  el.style.fontSize = size + 'px';
  el.style.setProperty('--drift', (Math.random() * 80 - 40) + 'px');
  const duration = 9 + Math.random() * 8;
  el.style.animationDuration = duration + 's';
  ambientLayer.appendChild(el);
  setTimeout(() => el.remove(), duration * 1000 + 200);
}

setInterval(spawnFloaty, 900);
for (let i = 0; i < 4; i++) setTimeout(spawnFloaty, i * 300);

// ---- CONFETTI (canvas) --------------------------------------------------
const confettiCanvas = document.getElementById('confetti-canvas');
const ctx = confettiCanvas.getContext('2d');
let confettiPieces = [];
let confettiAnimating = false;

function resizeCanvas() {
  confettiCanvas.width = window.innerWidth;
  confettiCanvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

const confettiColors = [CONFIG.colors.accent, CONFIG.colors.accentStrong, CONFIG.colors.gold, '#ffffff'];

function burstConfetti() {
  const count = 90;
  for (let i = 0; i < count; i++) {
    confettiPieces.push({
      x: confettiCanvas.width / 2 + (Math.random() * 140 - 70),
      y: confettiCanvas.height * 0.35,
      vx: (Math.random() - 0.5) * 9,
      vy: Math.random() * -9 - 3,
      size: 4 + Math.random() * 5,
      color: confettiColors[Math.floor(Math.random() * confettiColors.length)],
      rotation: Math.random() * 360,
      rotSpeed: (Math.random() - 0.5) * 12,
      gravity: 0.22 + Math.random() * 0.08,
      life: 0,
      maxLife: 130 + Math.random() * 40
    });
  }
  if (!confettiAnimating) {
    confettiAnimating = true;
    requestAnimationFrame(animateConfetti);
  }
}

function animateConfetti() {
  ctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
  confettiPieces.forEach(p => {
    p.vy += p.gravity;
    p.x += p.vx;
    p.y += p.vy;
    p.rotation += p.rotSpeed;
    p.life++;

    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate((p.rotation * Math.PI) / 180);
    ctx.globalAlpha = Math.max(0, 1 - p.life / p.maxLife);
    ctx.fillStyle = p.color;
    ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
    ctx.restore();
  });

  confettiPieces = confettiPieces.filter(p => p.life < p.maxLife && p.y < confettiCanvas.height + 40);

  if (confettiPieces.length > 0) {
    requestAnimationFrame(animateConfetti);
  } else {
    confettiAnimating = false;
    ctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
  }
}
